using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using SalesAPI.Models;

public static class DataSeeder
{
    public static void SeedData(ApiDbContext context)
    {
        if (!context.Products.Any())
        {
            context.Products.AddRange(
                new Product { Id = Guid.NewGuid(), Name = "Product 1", Description = "Description 1", Price = 10.0m },
                new Product { Id = Guid.NewGuid(), Name = "Product 2", Description = "Description 2", Price = 20.0m }
            );
            context.SaveChanges();
        }

        if (!context.Customers.Any())
        {
            context.Customers.AddRange(
                new Customer { Id = Guid.NewGuid(), Name = "Customer 1", Email = "customer1@example.com" },
                new Customer { Id = Guid.NewGuid(), Name = "Customer 2", Email = "customer2@example.com" }
            );
            context.SaveChanges();
        }
    }
}