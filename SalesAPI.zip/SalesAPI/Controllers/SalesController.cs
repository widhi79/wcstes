using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using SalesAPI.Models; 
using System.Text.Json;
using System.Text.Json.Serialization;

[ApiController]
[Route("api/[controller]")]
public class SalesController : ControllerBase
{
    private readonly ApiDbContext _context;
    private readonly JsonSerializerOptions _jsonSerializerOptions;

    public SalesController(ApiDbContext context)
    {
        _context = context;

        // Configure JsonSerializerOptions with ReferenceHandler.Preserve
        _jsonSerializerOptions = new JsonSerializerOptions
        {
            ReferenceHandler = ReferenceHandler.Preserve,
            // You can add more options if needed, e.g., PropertyNamingPolicy, etc.
        };
    }

    [HttpGet]
    public IActionResult GetSales(int page = 1, int pageSize = 10)
    {
        var salesWithLines = _context.Sales
            .Include(s => s.SalesLines)
            .OrderByDescending(s => s.CreateDate)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToList();

        // Serialize the data using the configured options
        var serializedData = JsonSerializer.Serialize(salesWithLines, _jsonSerializerOptions);

        return Ok(serializedData);
        //return Ok(salesWithLines);
    }

    [HttpPost]
    public IActionResult PostSales(Sales sales)
    {
        int runningNumber = _context.Sales.Count() + 1;
        sales.SalesNo = $"INV{runningNumber:0000}";

        // Perform validation for mandatory fields on sales and sales line
        if (sales.SalesLines == null || !sales.SalesLines.Any())
        {
            return BadRequest("Sales lines must not be empty.");
        }

        // Save sales data to the database
        _context.Sales.Add(sales);
        _context.SaveChanges();

        var serializedData = JsonSerializer.Serialize(sales, _jsonSerializerOptions);
        return Ok(serializedData);
        //return Ok(sales);
    }
}