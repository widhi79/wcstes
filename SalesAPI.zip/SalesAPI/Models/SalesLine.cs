using System;
using System.ComponentModel.DataAnnotations;

namespace SalesAPI.Models
{
    public class SalesLine
    {
        public Guid Id { get; set; }
        [Required(ErrorMessage = "ProductId is required.")]
        public Guid SalesId { get; set; }
        [Required(ErrorMessage = "ProductId is required.")]
        public Guid ProductId { get; set; }
        [Required(ErrorMessage = "ProductName is required.")]
        public string ProductName { get; set; }
        [Required(ErrorMessage = "Quantity is required.")]
        public int Quantity { get; set; }
        [Required(ErrorMessage = "UnitPrice is required.")]
        public decimal UnitPrice { get; set; }
        [Required(ErrorMessage = "Amount is required.")]
        public decimal Amount { get; set; }

        public Sales Sales { get; set; } // Add this navigation property
        public Product Product { get; set; } // Add this navigation property
    }
}
