using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SalesAPI.Models
{
    public class Sales
    {
        public Guid Id { get; set; }
        [Required(ErrorMessage = "CustomerId is required.")]
        public Guid CustomerId { get; set; }
        [Required(ErrorMessage = "SalesNo is required.")]
        public string SalesNo { get; set; }
        [Required(ErrorMessage = "TotalAmount is required.")]
        public decimal TotalAmount { get; set; }
        [Required(ErrorMessage = "CreateDate is required.")]
        public DateTime CreateDate { get; set; }

        public List<SalesLine> SalesLines { get; set; }
        public Customer Customer { get; set; } // Add this navigation property

    }
}
