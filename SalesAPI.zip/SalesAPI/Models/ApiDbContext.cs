using Microsoft.EntityFrameworkCore;
using Pomelo.EntityFrameworkCore.MySql.Infrastructure;
using SalesAPI.Models; 
using System;
using System.ComponentModel.DataAnnotations.Schema;

public class ApiDbContext : DbContext
{
    public ApiDbContext(DbContextOptions<ApiDbContext> options) : base(options)
    {
    }

    public DbSet<Product> Products { get; set; }
    public DbSet<Customer> Customers { get; set; }
    public DbSet<Sales> Sales { get; set; }
    public DbSet<SalesLine> SalesLines { get; set; }

    /*protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        base.OnConfiguring(optionsBuilder);

        // Set CharSetBehavior here
        optionsBuilder
            .UseCharSetBehavior(CharSetBehavior.NeverAppend);
    }*/

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // Define relationships and constraints here
        // Set up primary keys
        /*modelBuilder.Entity<Product>().HasKey(p => p.Id);
        modelBuilder.Entity<Customer>().HasKey(c => c.Id);
        modelBuilder.Entity<Sales>().HasKey(s => s.Id);
        modelBuilder.Entity<SalesLine>().HasKey(s => new { s.SalesId, s.ProductId }); // Composite key*/
                // Set up primary keys using GUID (UUID)
            modelBuilder.Entity<Product>().Property(p => p.Id).HasConversion<Guid>();
            modelBuilder.Entity<Customer>().Property(c => c.Id).HasConversion<Guid>();
            modelBuilder.Entity<Sales>().Property(s => s.Id).HasConversion<Guid>();
            modelBuilder.Entity<SalesLine>().Property(sl => sl.Id).HasConversion<Guid>();


        // Set up relationships
        modelBuilder.Entity<Sales>()
            .HasOne(s => s.Customer)
            .WithMany(c => c.Sales)
            .HasForeignKey(s => s.CustomerId)
            .OnDelete(DeleteBehavior.Cascade); // Use DeleteBehavior.Cascade if you want to delete Sales when Customer is deleted.

        modelBuilder.Entity<SalesLine>()
            .HasOne(sl => sl.Sales)
            .WithMany(s => s.SalesLines)
            .HasForeignKey(sl => sl.SalesId)
            .OnDelete(DeleteBehavior.Cascade); // Use DeleteBehavior.Cascade if you want to delete SalesLines when Sales is deleted.

        modelBuilder.Entity<SalesLine>()
            .HasOne(sl => sl.Product)
            .WithMany(p => p.SalesLines)
            .HasForeignKey(sl => sl.ProductId)
            .OnDelete(DeleteBehavior.Cascade); // Use DeleteBehavior.Cascade if you want to delete SalesLines when Product is deleted.

    }
}
