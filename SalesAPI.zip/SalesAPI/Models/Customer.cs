using System.Collections.Generic;
using System;

namespace SalesAPI.Models
{
    public class Customer
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }

        public List<Sales> Sales { get; set; } // Add this navigation property
    }
}
